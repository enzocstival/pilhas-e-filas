//abre um public para classe pilha com todos os atributos //
public class Pilha {
    private int capacidade;
    private int topo;
    private int[] dados;

    // Construtor para inicializar a pilha com uma capacidade específica, -1 para topo //
    public Pilha(int capacidade) {
        this.capacidade = capacidade;
        this.topo = -1;
        this.dados = new int[capacidade];
    }

    // insere um novo elemento na pilha, incrementa a pilha adicionando seus novo valores ao topo //
    public void insere(int elemento) {
        if (cheia()) {
            System.out.println("A pilha está cheia.");
            return;
        }
        dados[++topo] = elemento;
    }

    // verifica se a pilha está cheia, -1 da capacidade para deonstrar que está cheia
    public boolean cheia() {
        return topo == capacidade - 1;
    }

    // verifica se a pilha está vazia, se topo == -1 está vazia
    public boolean vazia() {
        return topo == -1;
    }

    //  remove um elemento da pilha
    public int remove() {
        if (vazia()) {
            System.out.println("A pilha está vazia.");
            return -1; // Valor indicativo de erro
        }
        return dados[topo--];
    }

    //imprime todos os elementos da pilha, possui um array que percorre de 0 até o topo para mostrar todos os dados obtidos ao usuário
    public void imprime() {
        if (vazia()) {
            System.out.println("A pilha está vazia.");
            return;
        }
        System.out.print("Elementos da pilha: ");
        for (int i = 0; i <= topo; i++) {
            System.out.print(dados[i] + " ");
        }
        System.out.println();
    }
}
