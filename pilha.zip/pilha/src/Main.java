import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite a capacidade total pilha: ");
        int capacidade = scanner.nextInt();
        Pilha pilha = new Pilha(capacidade);

        int opcao;
//*** menu de opções do usuário ***//
        do {
            System.out.println("\nEscolha uma opção:");
            System.out.println("1. Adicionar valor na pilha");
            System.out.println("2. Remover valor da pilha");
            System.out.println("3. Imprimir valores da pilha");
            System.out.println("4. finalizar/sair ");
            System.out.print("Opção: ");
            opcao = scanner.nextInt();
// abre o switch para todas as opções que a pessoa possa escolher //
            switch (opcao) {
                case 1:
                    System.out.print("Digite o valor para inserir na pilha: ");
                    int valor = scanner.nextInt();
                    pilha.insere(valor);
                    break;

                case 2:
                    int removido = pilha.remove();
                    if (removido != -1) {
                        System.out.println("Valor removido: " + removido);
                    }
                    break;

                case 3:
                    pilha.imprime();
                    break;

                case 4:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }

        } while (opcao != 4);
//fecha o scanner pois não terá mais entradas de valores
        scanner.close();
    }
}
