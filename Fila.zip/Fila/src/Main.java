import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("******BEM-VINDO USUÁRIO******");
        System.out.print("Digite a capacidade da sua fila: ");

        int capacidade = scanner.nextInt();
        Fila fila = new Fila(capacidade);

        int opcao;
// **************menu****************************************//
        do {
            System.out.println("\n****WELCOME TO MENU****");
            System.out.println("Escolha uma opção:");
            System.out.println("1. Adicionar valor na fila");
            System.out.println("2. Remover valor da fila");
            System.out.println("3. Imprimir elementos da fila");
            System.out.println("4. Sair");
            System.out.print("Opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Digite o valor a ser inserido na fila: ");
                    int valor = scanner.nextInt();
                    fila.insere(valor);
                    break;

                case 2:
                    int removido = fila.remove();
                    if (removido != -1) {
                        System.out.println("Valor removido: " + removido);
                    }
                    break;

                case 3:
                    fila.imprime();
                    break;

                case 4:
                    System.out.println("Saindo...");
                    try {
                        Thread.sleep(1000); // Pausa de 1 segundo
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("**fim de programa**");
                    break;


                default:
                    System.out.println("\nOpção inválida. Tente novamente.");
                    break;
            }

        } while (opcao != 4);
        scanner.close();
    }
}
