public class Fila {
    private int capacidade;
    private int primeiro;
    private int ultimo;
    private int[] dados;
    private int tamanho;


    public Fila(int capacidade) {
        this.capacidade = capacidade;
        this.dados = new int[capacidade];
        this.primeiro = 0;
        this.ultimo = -1;
        this.tamanho = 0;
    }

    // verifica se a fila está cheia
    public boolean cheia() {
        return tamanho == capacidade;
    }

    // verifica se a fila está vazia
    public boolean vazia() {
        return tamanho == 0;
    }

    // insere um novo elemento na fila
    public void insere(int elemento) {
        if (cheia()) {
            System.out.println("A fila está cheia.");
            return;
        }
        primeiro = (primeiro + 1) % capacidade;
        dados[primeiro] = elemento;
        tamanho++;
    }


    public int remove() {
        if (vazia()) {
            System.out.println("A fila está vazia.");
            return -1; // Valor indicativo de erro
        }
        int elementoRemovido = dados[primeiro];
        primeiro = (primeiro + 1) % capacidade;
        tamanho--;
        return elementoRemovido;
    }


    public void imprime() {
        if (vazia()) {
            System.out.println("A fila está vazia.");
            return;
        }
        System.out.print("Elementos da fila: ");
        for (int i = 0; i < tamanho; i++) {
            int index = (primeiro + i) % capacidade;
            System.out.print(dados[index] + " ");
        }
        System.out.println();
    }
}
